/*	see copyright notice in squirrel.h */
#ifndef _SQSTD_MATH_H_
#define _SQSTD_MATH_H_

SQRESULT sqstd_register_mathlib(HSQUIRRELVM v);

#endif /*_SQSTD_MATH_H_*/
