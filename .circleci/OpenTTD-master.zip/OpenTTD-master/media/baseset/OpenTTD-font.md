# OpenTTD TrueType font

The OpenTTD TrueType font was created by Zephyris and is maintained on [Github](https://github.com/zephyris/openttd-ttf).
It is licensed under GPL-2.0.

The currently included files correspond to release v0.6.
