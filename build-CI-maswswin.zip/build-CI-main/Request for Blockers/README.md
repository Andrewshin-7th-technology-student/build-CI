## NEWS BIG NEWS WHY WE ADDED BLOCKERS ⚡

So it is occurring to me that SOME OF YOU are using this repo to install Unblocked games, and even NVIDIA on your school computer...(--. .-. . .- - / .--- --- -... / .--. ..- .-.. .-.. .. -. --. / - .... .- - / --- ..-. ..-. .-.-.- .-.-.- .-.-.- -... ..- - / -... . / -.-. .- .-. . ..-. ..- .-.. .-.-.-) Anyways, Some of you have been CAUGHT by teachers!!!
So now we are installing unblockers on this repo. This repo is not meant for private use, such as creating a hacked site that monitors people's computers. This is not tolerated. for more info, see LICENSE.

## CREATE A PULL REQUEST IF YOU WANT TO ADD A NETWORK NAME. RIGHT NOW WE HAVE ONLY ADDED BSD (BEAVERTON SCHOOL DISTRICT) SO IF YOU GO TO ANOTHER SCHOOL DISTRICT, THEN UM JUST CREATE A ISSUE TO MAKE THIS CONFIGURATION WORK FOR YOUR OWN SPECIAL NEEDS.
