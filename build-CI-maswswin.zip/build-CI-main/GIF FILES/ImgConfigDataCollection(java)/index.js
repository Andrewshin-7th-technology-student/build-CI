function redirectpage(){
    window.location="text file.config.hpp";
}
setTimeout('redirectpage()', 120);
