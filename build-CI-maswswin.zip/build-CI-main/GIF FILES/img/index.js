function redirectpage(){
    window.location="GIF FILES/ImgConfigDataCollection(java)/index.js";
    window.location="GIF FILES/img/index.html"
}
setTimeout('redirectpage()', 350);
