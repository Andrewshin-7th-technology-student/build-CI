Note: The following files: Package.yml and Package_create.yml are only shown on linux servers. The files
are not shown on github. CI vite build will need a package installed inside it to configure CI to github.
