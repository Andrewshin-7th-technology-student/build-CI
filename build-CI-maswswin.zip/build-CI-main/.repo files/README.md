## the folder "md files" may have no affect on current repository changes.

Contributors may not remove or alter any copyright, patent,
trademark, attribution notices, disclaimers of warranty, or limitations
of liability ("notices") contained within the Program from any copy of
the Program which they Distribute, provided that Contributors may add
their own appropriate notices.

Contributors also may not remove any .MD files due to the LICENSE rules
but README.MD files may be alterd by contributors. The origin of this
software must not be misrepresented; you must not claim thatyou wrote the
original software. If you use this software in a product, an acknowledgment
in the product documentation would be appreciated but is not required.

## NOTE THAT ONLY THE LICENSE.MD , SECURITY.MD, COPYRIGHT.MD, UPGRADE.MD, AND CODE_OF_CONDUCT.MD FILES MAY HAVE AFFECT ON THIS REPOSITORY.NONE PRESSED CHANGES. CONTRIBUTORS.MD ARE PEOPLE WHO HAVE CONTRIBUTED CODE TO THIS REPO. NONE OF THE PEOPLE IN THE FILE ARE NOT SUPPORTING CODE.
