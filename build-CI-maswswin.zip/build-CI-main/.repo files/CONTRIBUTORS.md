# This file contains a list of people who've made non-trivial

# contribution to the CI-BUILD project.  People

# who commit code to the project are encouraged to add their names

# here.  Please keep the list sorted by first names.

Henry Robinson <Henryuser13@outlook.com>
Elsa Preper <buildingcodetacouserlover9921@gmail.com>
Daphene Somersion <FrozenICICLE@gmail.com>
Andrew Shin (7th grade) <p1480132@outlook.com> or <andrewshinawesomeTECT@hotmail.com>
Andrew Shin (9th grade) <p1480132@outlook.com> or <andrewshin90909@gmail.com>
