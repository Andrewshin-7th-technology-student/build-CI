Contributing to build-CI
build-CI is initially designed and implemented by browser vendors who are interested in meeting a variety of use cases. As design and implementation progresses they'll need input and contributions from developers interested in using yml files for CI vite build.

Interested in participating? We suggest you start by:

1. fix any errors, or make a pull request that has been approved by a contributer.
1. run YAML files in a clone to intercept YAML - vite build config.
