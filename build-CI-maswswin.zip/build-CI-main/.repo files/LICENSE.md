The GNU GPL is the most widely used free software license and has a strong copyleft requirement. When distributing derived works, the source code of the work must be made available under the same license. There are multiple variants of the GNU GPL, each with different requirements.

## Permissions

Commercial use?🆗
Modification🆗
Distribution🆗
Private use🆗

## Limitations

Liability🚫
Warranty🚫

## Conditions

License and copyright notice
State changes
Disclose source
Same license
This is not legal advice. Learn more about repository licenses.
