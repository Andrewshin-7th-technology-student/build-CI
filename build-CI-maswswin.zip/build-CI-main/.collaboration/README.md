## note that the links in this folder are not for use in privite.

## if you want to see terms and conditions, please refer to ./repo files/.COLLABORATION_FOLDER.md

or ("https://github.com/Andrewshin-7th-technology-student/build-CI/blob/main/.repo%20files/.COLLABORATION_FOLDER.md")
